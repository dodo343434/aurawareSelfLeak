#include "options.hpp"

Config g_Options;
bool   g_Unload = false;
bool   g_Save = false;
bool   g_Load = false;
bool   g_Clear = false;
bool   g_View = false;