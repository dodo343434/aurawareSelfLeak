#include "../MainInclude.hpp"
/*
class AA : public Singleton<AA>
{ 
public:
void LAA(CUserCmd *pCmd, bool& bSendPacket);
void LAAFIX(CUserCmd * cmd, bool & bSendPacket);
	};
	*/