#include "../MainInclude.hpp"
namespace triggerbot
{
	void Triggerbot(CUserCmd* pCmd);
}